// Hand-written public API types (PKG-02 / D-09).
// Mirrors the EXACT runtime shape — verified against src/mount.js (validateConfig +
// handle) and src/adapters/result.js (the emitted payload). Kept in sync by a
// `tsc --noEmit` consumer check (types/consumer.test-d.ts); never generated.

/** Player identity passed by the host. `id` is opaque and echoed back untouched. */
export interface GoatPlayer {
  /** Opaque host identifier — carried through verbatim into the result (never inspected). */
  id?: unknown;
  /** Display name. Empty/missing degrades to 'Player' (never throws). */
  name: string;
  /**
   * Optional lifetime coin pool the host keeps for this player (e.g. 150). Displayed
   * in-game (start/HUD/game-over) and echoed for display only — never interpreted.
   * Normalized to a non-negative integer; negative/NaN/non-number/absent → hidden.
   * Additive & backward-compatible; the host accumulates it via `result.coins`.
   */
  coins?: number;
}

/** A single leaderboard row supplied by the host (the "Hall of the Chased" board). */
export interface GoatLeaderboardEntry {
  name: string;
  team?: string;
  distance: number;
}

/** A row of the optional coins leaderboard (the engagement board, by total coins). */
export interface GoatCoinLeaderboardEntry {
  name: string;
  team?: string;
  /** The player's total coins (their lifetime pool). Sorted descending; clamped to a non-negative integer. */
  coins: number;
}

/** The once-per-run result handed to onGameEnd. */
export interface GoatResult {
  /** Echo of the host's GoatPlayer.id (opaque). */
  id: unknown;
  name: string;
  /** Integer metres survived. */
  distance: number;
  /**
   * Coins collected THIS run (integer, ≥ 0) — a separate metric from `distance`.
   * Always present (0 when none). Additive; the host pools it: `pool += result.coins`.
   */
  coins: number;
  /**
   * The run's length on the ACTIVE simulation clock, in integer milliseconds (AC-04).
   * Measured from the same fixed-timestep loop that advances distance, so it EXCLUDES
   * paused time (tab-blur) and the intro/knockdown phases. Always present. The host's
   * server validates a run by reproducing the pacing curve:
   * `|distance − paceDistance(durationMs)| ≤ ε`.
   */
  durationMs: number;
  /**
   * Echo of the host's `config.runToken` (AC-03) — opaque, carried through UNTOUCHED.
   * Present iff a non-empty token was current when the run ended (set via `config.runToken`
   * or `handle.setRunToken`); OMITTED entirely otherwise. The bundle never interprets it.
   */
  runToken?: string;
  /** ISO-8601 string (e.g. '2026-06-29T12:34:56.789Z') — NOT a Date. */
  timestamp: string;
}

export interface GoatConfig {
  player?: GoatPlayer;
  leaderboard?: GoatLeaderboardEntry[];
  /** REQUIRED — a non-function throws at mount/update time. Fires exactly once per run. */
  onGameEnd: (result: GoatResult) => void;
  /**
   * Game audio (synthesized stadium crowd bed + MEEEH/SIUUUU cues). ON by default.
   * Pass `false` to force-mute, `true` to force-enable, or an object to set the volume.
   * Invalid values degrade to the default and NEVER throw. A visible HUD mute toggle
   * lets the player flip it at runtime (the preference persists locally when storage allows).
   * - omitted   → enabled, default volume
   * - `false`   → muted (host force-mute)
   * - `true`    → enabled, default volume
   * - object    → `enabled` defaults to true; `volume` is clamped to 0..1 (default 0.6)
   */
  audio?: boolean | { enabled?: boolean; volume?: number };
  /**
   * Optional override for the World Cup bracket checkpoints. Overrides the baked-in
   * `2000 → Group Stage`, `4000 → Round of 16`, `6000 → Quarter-Final`,
   * `8000 → Semi-Final`, `10000 → Final`, `15000 → Champion` map
   * (Champion is the open-ended top tier — held for any distance beyond 15000).
   * - omitted   → the baked-in defaults
   * - malformed (non-array, empty, or rows lacking a finite `distance`/usable `label`)
   *   degrades to the defaults and NEVER throws
   * The array is cloned & sorted ascending; the host `label` strings are rendered as
   * TEXT only (canvas fillText / DOM textContent — never innerHTML).
   */
  milestones?: Array<{ distance: number; label: string }>;
  /**
   * Optional coins leaderboard (engagement) — rendered as a SECOND board under the distance
   * "Hall of the Chased", ranked by `coins` descending (capped at 20). Host-supplied, like
   * `leaderboard`. Omitted/empty/malformed → the board is hidden entirely (no regression).
   * Read-only/cloned (never mutated). Refresh it live via `handle.setCoinLeaderboard(...)`.
   */
  coinLeaderboard?: GoatCoinLeaderboardEntry[];
  /**
   * Optional anti-cheat token (AC-01) — an OPAQUE host-supplied string the bundle carries
   * through and echoes back in `result.runToken`. The bundle NEVER interprets, parses,
   * validates, transmits, or renders it (treated exactly like `player.id`). Missing/empty →
   * the result's `runToken` is omitted. The host issues a signed, single-use token, then
   * arms the next run after each result via `handle.setRunToken`.
   */
  runToken?: string;
}

export interface GoatGameHandle {
  /** Unmount: remove the canvas/listeners/rAF/observer and registered fonts; the container is left empty. */
  destroy(): void;
  /**
   * Refresh ONLY the leaderboard, keeping the current player + onGameEnd. The intended
   * post-run flow: onGameEnd saves the score → host re-fetches the now-changed leaderboard
   * → setLeaderboard(fresh) so the game-over and next start board show the new standings.
   * Re-validates & clones the array (never mutates the host's array). NEVER interrupts an
   * active run, replays the intro, or fires onGameEnd.
   */
  setLeaderboard(leaderboard: GoatLeaderboardEntry[]): void;
  /**
   * Refresh ONLY the coins leaderboard (engagement board), keeping player + distance board +
   * onGameEnd. The post-run flow mirrors setLeaderboard: pool `result.coins`, re-fetch the coin
   * standings, then setCoinLeaderboard(fresh). Re-validates & clones; never interrupts a run,
   * replays the intro, or fires onGameEnd. An empty array hides the board.
   */
  setCoinLeaderboard(coinLeaderboard: GoatCoinLeaderboardEntry[]): void;
  /** Refresh ONLY the player {id,name}, keeping the leaderboard. Same run-safety as setLeaderboard. */
  setPlayer(player: GoatPlayer): void;
  /**
   * Replace ONLY the stored anti-cheat token (AC-02), keeping player/leaderboards/onGameEnd
   * intact. The host's token is single-use: after each run it submits the result, fetches a
   * fresh token, and calls this to arm the next run. The token echoed in a result is whichever
   * is current at the moment that run ENDS. Same run-safety as setLeaderboard — NEVER interrupts
   * an active run, replays the intro, or fires onGameEnd. Empty/non-string → the next result
   * omits runToken.
   */
  setRunToken(token: string): void;
  /**
   * Refresh BOTH the stored leaderboard and player between runs (full config). Re-validates
   * (clone-on-derive, never mutates the host's objects) and re-renders only the board that is
   * or will next be shown. NEVER interrupts an active run, replays the intro, or fires onGameEnd.
   * Note: omitting `player` resets the name to "Player" — use setLeaderboard() for a
   * leaderboard-only refresh.
   */
  update(config: GoatConfig): void;
}

/**
 * Mount the game into `container`.
 * @throws Error 'mountGoatGame: container must be a DOM element' — if `container` is not a DOM element.
 * @throws Error 'mountGoatGame: onGameEnd must be a function' — if `config.onGameEnd` is missing or not a function.
 */
export function mountGoatGame(container: HTMLElement, config: GoatConfig): GoatGameHandle;

/**
 * The pacing curve as a portable source of truth (AC-05): the total integer metres covered
 * after `activeMs` of ACTIVE play, using the EXACT speed ramp the game loop runs each frame.
 * The host's server reproduces this to validate a result —
 * `|result.distance − paceDistance(result.durationMs)| ≤ ε` (small frame-rounding ε).
 * Pure; non-positive/garbage input → 0. The constants and exact algorithm are in INTEGRATION.md §8.
 */
export function paceDistance(activeMs: number): number;
